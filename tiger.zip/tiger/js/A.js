var web3Provider;
    if (window.ethereum) {
        web3Provider = window.ethereum;
        try {
            // 请求用户授权
             window.ethereum.enable();
        } catch (error) {
            // 用户不授权时
            console.error("User denied account access")
        }
    }
    web3js = new Web3(web3Provider);//web3js就是你需要的web3实例
 
    web3js.eth.getAccounts(function (error, result) {
        if (!error)
            console.log(result)//授权成功后result能正常获取到账号了
    });
