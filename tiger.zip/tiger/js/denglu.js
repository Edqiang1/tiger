window.addEventListener('load', function() {
	 if (!web3.eth.coinbase) {//这个是判断你有没有登录，coinbase是你此时选择的账号
              window.alert('检测到已安装Metamask 请先连接钱包');
              return;
            }
          // Checking if Web3 has been injected by the browser (Mist/MetaMask)
            if (typeof web3 !== 'undefined') {
				　　　　}
　　　　});
