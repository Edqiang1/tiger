 window.addEventListener('load', function() {
            if (!window.web3) {//用来判断你是否安装了metamask
              window.alert('检测到未安装 MetaMask.');//如果没有会去提示你先去安装
              return;
				
　　　　　　　}
　　　　});
