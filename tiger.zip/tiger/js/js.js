new Vue({
  el: '#app',
  data: {
    clickMsg: [
      {
        img: 'images/boos.png',
        bz: 'boos',
        tz: 0
      },
      {
        img: 'images/shuangxing.png',
        bz: 'sx',
        tz: 0
      },
      {
        img: 'images/shuangqi.png',
        bz: 'sq',
        tz: 0
      },
      {
        img: 'images/xigua.png',
        bz: 'xg',
        tz: 0
      },
      {
        img: 'images/lingdang.png',
        bz: 'ld',
        tz: 0
      },
      {
        img: 'images/ningmeng.png',
        bz: 'nm',
        tz: 0
      },
      {
        img: 'images/juzi.png',
        bz: 'jz',
        tz: 0
      },
      {
        img: 'images/pingguo.png',
        bz: 'pg',
        tz: 0
      },
    ],
    boxMsg: [
      {
        img: 'images/juzi.png',
        active: '0',
        bs: 10,
        name: '橘子',
        tz: 0,
        id: 0,
        state: 'xsy',
        bz: 'jz'
      },
      {
        img: 'images/lingdang.png',
        active: '0',
        bs: 10,
        name: '铃铛',
        tz: 0,
        id: 1,
        state: 'da',
        bz: 'ld'
      },
      {
        img: 'images/boos_x.png',
        active: '0',
        bs: 25,
        name: '小BAR',
        tz: 0,
        id: 2,
        state: 'xiao',
        bz: 'boos'
      },
      {
        img: 'images/boos.png',
        active: '0',
        bs: 50,
        name: 'BAR',
        tz: 0,
        id: 3,
        state: 'da',
        bz: 'boos'
      },
      {
        img: 'images/pingguo.png',
        active: '0',
        bs: 5,
        name: '苹果',
        tz: 0,
        id: 4,
        state: 'xsx',
        bz: 'pg'
      },
      {
        img: 'images/pingguo_x.png',
        active: '0',
        bs: 2,
        name: '小苹果',
        tz: 0,
        id: 5,
        state: 'xiao',
        bz: 'pg'
      },
      {
        img: 'images/ningmeng.png',
        active: '0',
        bs: 10,
        name: '柠檬',
        tz: 0,
        id: 6,
        state: 'da',
        bz: 'nm'
      },
      {
        img: 'images/xigua.png',
        active: '0',
        bs: 20,
        name: '西瓜',
        tz: 0,
        id: 7,
        state: 'dsy',
        bz: 'xg'
      },
      {
        img: 'images/xigua_x.png',
        active: '0',
        bs: 2,
        name: '小西瓜',
        tz: 0,
        id: 8,
        state: 'xiao',
        bz: 'xg'
      },
      {
        img: 'images/luck1.png',
        active: '0',
        bs: 0,
        name: '幸运奖',
        tz: 0,
        bz: 'xy'
      },
      {
        img: 'images/pingguo.png',
        active: '0',
        bs: 5,
        name: '苹果',
        tz: 0,
        id: 9,
        state: 'xsx',
        bz: 'pg'
      },
      {
        img: 'images/juzi_x.png',
        active: '0',
        bs: 2,
        name: '小橘子',
        tz: 0,
        id: 10,
        state: 'xiao',
        bz: 'jz'
      },
      {
        img: 'images/juzi.png',
        active: '0',
        bs: 10,
        name: '橘子',
        tz: 0,
        id: 11,
        state: 'da',
        bz: 'jz'
      },
      {
        img: 'images/lingdang.png',
        active: '0',
        bs: 10,
        name: '铃铛',
        tz: 0,
        id: 12,
        state: 'xsy',
        bz: 'ld'
      },
      {
        img: 'images/shuangqi_x.png',
        active: '0',
        bs: 2,
        name: '小双7',
        tz: 0,
        id: 13,
        state: 'xiao',
        bz: 'sq'
      },
      {
        img: 'images/shuangqi.png',
        active: '0',
        bs: 20,
        name: '双7',
        tz: 0,
        id: 14,
        state: 'dsy',
        bz: 'sq'
      },
      {
        img: 'images/pingguo.png',
        active: '0',
        bs: 5,
        name: '苹果',
        tz: 0,
        id: 15,
        state: 'xsx',
        bz: 'pg'
      },
      {
        img: 'images/ningmeng_x.png',
        active: '0',
        bs: 2,
        name: '小柠檬',
        tz: 0,
        id: 16,
        state: 'xiao',
        bz: 'nm'
      },
      {
        img: 'images/ningmeng.png',
        active: '0',
        bs: 10,
        name: '柠檬',
        tz: 0,
        id: 17,
        state: 'xsy',
        bz: 'nm'
      },
      {
        img: 'images/shuangxing.png',
        active: '0',
        bs: 20,
        name: '双星',
        tz: 0,
        id: 18,
        state: 'dsy',
        bz: 'sx'
      },
      {
        img: 'images/shuangxing_x.png',
        active: '0',
        bs: 2,
        name: '小双星',
        tz: 0,
        id: 19,
        state: 'xiao',
        bz: 'sx'
      },
      {
        img: 'images/luck2.png',
        active: '0',
        bs: 0,
        name: '幸运奖',
        tz: 0,
        bz: 'xy'
      },
      {
        img: 'images/pingguo.png',
        active: '0',
        bs: 5,
        name: '苹果',
        tz: 0,
        id: 20,
        state: 'xsx',
        bz: 'pg'
      },
      {
        img: 'images/lingdang_x.png',
        active: '0',
        bs: 2,
        name: '小铃铛',
        tz: 0,
        id: 21,
        state: 'xiao',
        bz: 'ld'
      },
    ],
    speed: 0,
    startNum: 0,
    runNum: 0,
    state: 0,
    runMsg: '',
    money: 3,
    grades: 0,
    alertMsg: '',
    prizeAry: ['大三元', '小三元', '小四喜', '开火车', '超级大满贯'],
    prizeName: '',
    gradesAry: [],
    introduce: 0,
    chooseColor: 1
  },
  methods: {
    castMoney: function () {
      if (this.money == 0) {
        this.alert("没币了┭┮﹏┭┮", 2)
      } else {
        this.money = --this.money
        this.grades = 10 + this.grades
      }
    },
    getRandom: function (min, max) {
      return Math.floor(Math.random() * (max - min + 1) + min)
    },
    sum(data) {
      return eval(data.join("+"))
    },
    begin: function () {
      let data = JSON.parse(sessionStorage.getItem('history'))
      if (data) {
        let gradesAry = []
        for (let i = 0; i < data.clickMsg.length; i++) {
          gradesAry.push(data.clickMsg[i].tz)
        }
        if (this.grades - this.sum(gradesAry) < 0) {
          this.alert("分数不足请重新下注或投币！", 3)
          return
        }
        this.grades = this.grades - this.sum(gradesAry)
        this.clickMsg = data.clickMsg
        this.boxMsg = data.boxMsg
      }
      let ary = []
      for (let i = 0; i < this.clickMsg.length; i++) {
        if (this.clickMsg[i].tz != 0) {
          ary.push(i)
        }
      }
      if (ary.length == 0) {
        this.alert("请点击最下面一排红色按钮下注!", 2)
      } else {
        this.start()
      }
    },
    start: function () {
      this.state = 1
      this.speed = 0
      this.clearbigSlamTimer()
      this.chooseColor = 1

      this.startNum = this.getRandom(0, 23)
      // this.startNum = 6

      this.runNum = this.getRandom(40, 40)
      this.run()
    },
    run: function () {
      if (this.train != '1') {
        this.prizeName = ""
      }
      this.runMsg = ""
      let that = this
      let runNum = ++that.speed
      setTime: setTimeout(function () {
        let addActive = ++that.startNum
        if (runNum == that.runNum) {
          if (that.train == '1') {
            that.prizeSet('khc')
            clearTimeout(that.setTime)
          } else {
            that.getChoose()
            clearTimeout(that.setTime)
          }
        } else {
          that.run()
          that.removeActive()
          if (that.train == '1') {
            for (let i = 0; i < that.trainLength; i++) {
              that.boxMsg[(addActive + i) % 24].active = '1'
            }
          } else {
            that.boxMsg[addActive % 24].active = '1'
          }
        }
      }, runNum * 5)
    },
    removeActive: function () {
      for (let i = 0; i < this.boxMsg.length; i++) {
        this.boxMsg[i].active = '0'
      }
    },
    removeBet: function () {
      let data = {
        boxMsg: this.boxMsg,
        clickMsg: this.clickMsg
      }
      sessionStorage.setItem('history', JSON.stringify(data))
      for (let i = 0; i < this.boxMsg.length; i++) {
        this.boxMsg[i].tz = 0
      }
      for (let i = 0; i < this.clickMsg.length; i++) {
        this.clickMsg[i].tz = 0
      }
    },
    getChoose: function () {
      this.gradesAry = []
      for (let i = 0; i < this.boxMsg.length; i++) {
        if (this.boxMsg[i].active == '1') {
          if (this.boxMsg[i].bs == 0) {
            this.prizeName = this.prizeAry[this.getRandom(0, 4)]
            if (this.prizeName == '大三元') {
              this.removeActive()
              this.prizeSet('dsy')
            } else if (this.prizeName == '小三元') {
              this.removeActive()
              this.prizeSet('xsy')
            } else if (this.prizeName == '小四喜') {
              this.removeActive()
              this.prizeSet('xsx')
            } else if (this.prizeName == '开火车') {
              this.trainLength = this.getRandom(3, 10)
              if (this.train != 1) {
                let that = this
                setTimeout(function () {
                  that.start()
                }, 500)
              }
              this.train = 1
            } else if (this.prizeName == '超级大满贯') {
              let that = this
              this.bigSlamTimer = setInterval(function () {
                if (that.chooseColor == 1) {
                  that.chooseColor = 0
                } else {
                  that.chooseColor = 1
                }
              }, 500)
              this.removeActive()
              this.prizeSet('cjdmg')
            }
          } else {
            this.gradesAry.push(this.boxMsg[i].tz * this.boxMsg[i].bs)
            this.runMsg = this.getAllGrades(this.gradesAry)
            this.grades = this.grades + this.getAllGrades(this.gradesAry)
            if (this.money == 0 && this.grades == 0) {
              this.alert("输完了,好笨鸭!", 10)
            }
            this.resetting()
          }
        }
      }
    },
    prizeSet: function (type) {
      let that = this
      setTimeout(function () {
        if (type == 'khc') {
          for (let i = 0; i < that.boxMsg.length; i++) {
            if (that.boxMsg[i].active == '1') {
              that.gradesAry.push(that.boxMsg[i].tz * that.boxMsg[i].bs)
            }
          }
          that.train = 0
        } else if (type == 'cjdmg') {
          for (let i = 0; i < that.boxMsg.length; i++) {
            that.boxMsg[i].active = '1'
            if (that.boxMsg[i].active == '1') {
              that.gradesAry.push(that.boxMsg[i].tz * that.boxMsg[i].bs)
            }
          }
        } else {
          for (let i = 0; i < that.boxMsg.length; i++) {
            if (that.boxMsg[i].state == type) {
              that.boxMsg[i].active = '1'
            }
            if (that.boxMsg[i].active == '1') {
              that.gradesAry.push(that.boxMsg[i].tz * that.boxMsg[i].bs)
            }
          }
        }
        that.runMsg = that.getAllGrades(that.gradesAry)
        that.grades = that.grades + that.getAllGrades(that.gradesAry)
        if (that.money == 0 && that.grades == 0) {
          that.alert("输完了,好笨鸭!", 10)
        }
        that.resetting()
      }, 500)
    },
    resetting: function () {
      let that = this
      that.speed = 0
      that.state = 0
      that.removeBet()
    },
    getAllGrades: function (arr) {
      var len = arr.length
      if (len == 0) {
        return 0
      } else if (len == 1) {
        return arr[0]
      } else {
        return arr[0] + this.getAllGrades(arr.slice(1))
      }
    },
    alert: function (msg, time) {
      let that = this
      that.alertMsg = msg
      setTime: setTimeout(function () {
        that.alertMsg = ''
      }, time * 1000)
    },
    alertClose: function () {
      this.alertMsg = ''
    },
    introduceBlock: function () {
      this.introduce = 1
    },
    introduceNone: function () {
      this.introduce = 0
    },
    addMoney: function (index) {
      sessionStorage.removeItem("history")
      if (this.state == 0) {
        if (this.grades == 0) {
          this.alert("没分了┭┮﹏┭┮,请点击右上角红色投币按钮投币!", 3)
        } else {
          this.grades = --this.grades
          this.clickMsg[index].tz = ++this.clickMsg[index].tz
          for (let i = 0; i < this.boxMsg.length; i++) {
            if (this.boxMsg[i].bz == this.clickMsg[index].bz) {
              this.boxMsg[i].tz = this.clickMsg[index].tz
            }
          }
        }
      }
    },
    addMoneyLongTime: function (index) {
      sessionStorage.removeItem("history")
      let that = this
      if (this.state == 0) {
        that.timer = setInterval(() => {
          if (that.grades == 0) {
            that.alert("没分了┭┮﹏┭┮,请点击右上角红色投币按钮投币!", 3)
          } else {
            that.grades = --that.grades
            that.clickMsg[index].tz = ++that.clickMsg[index].tz
            for (let i = 0; i < that.boxMsg.length; i++) {
              if (that.boxMsg[i].bz == that.clickMsg[index].bz) {
                that.boxMsg[i].tz = that.clickMsg[index].tz
              }
            }
          }
        }, 150)
      }
    },
    clearTimer: function () {
      clearTimeout(this.timer)
      this.timer = null
    },
    clearbigSlamTimer: function () {
      clearTimeout(this.bigSlamTimer)
      this.bigSlamTimer = null
    }
  }
})